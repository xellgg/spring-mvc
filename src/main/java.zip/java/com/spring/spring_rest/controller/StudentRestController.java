package com.spring.spring_rest.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.spring.spring_rest.dto.StudentDto;
import com.spring.spring_rest.entity.Student;
import com.spring.spring_rest.exception.StudentNotFoundException;
import com.spring.spring_rest.service.StudentService;

import jakarta.annotation.PostConstruct;
import jakarta.validation.Valid;


@RestController
@RequestMapping("/api/students")
public class StudentRestController {

    private StudentService studentService;

    public StudentRestController(StudentService studentService) {
        this.studentService = studentService;
    }

    // add students REST API
    @PostMapping
    public ResponseEntity<StudentDto> createStudents(@Valid @RequestBody StudentDto theStudentDto) {
        StudentDto saved = studentService.createStudent(theStudentDto);
        return new ResponseEntity<>(saved, HttpStatus.CREATED);
    }

    @GetMapping("{id}")
    public ResponseEntity<StudentDto> getStudentById(@PathVariable Long id) {
        StudentDto studentDto = studentService.getStudentById(id);
        return ResponseEntity.ok(studentDto);
    }
    
    @GetMapping
    public ResponseEntity<List<StudentDto>> getAllStudents(){
        List<StudentDto> students = studentService.getAllStudents();
        return ResponseEntity.ok(students);
    }
    
    @PutMapping("{id}")
    public ResponseEntity<StudentDto> updateStudent(@PathVariable Long id, @Valid 
                                                    @RequestBody StudentDto theStudentDto) {
        StudentDto studentDto = studentService.updateStudent(id, theStudentDto);
        return ResponseEntity.ok(studentDto);
    }

    @PutMapping("{id}")
    public ResponseEntity<StudentDto> patchStudent(@PathVariable Long id, @Valid
                                                    @RequestBody StudentDto theStudentDto) {
        StudentDto studentDto = studentService.patchStudent(id, theStudentDto);
        return ResponseEntity.ok(studentDto);
    }


    
    ////////////////////////////////////////////////////////////////////
    private List<Student> theStudents;

    @PostConstruct
    public void initialize() {
        theStudents = new ArrayList<>();

        theStudents.add(new Student(1L, "Jorl", "Centena", "jorl.centena@example.com"));
        theStudents.add(new Student(2L, "Nema", "Gojes", "nema.gojes@example.com"));
        theStudents.add(new Student(3L, "Rhotri", "Reboroso", "rhotri.reboroso@example.com"));
    }

    @GetMapping("/students")
    public List<Student> getStudents() {
        return theStudents;
    }

    @GetMapping("/students/{studentId}")
    public Student getStudent(@PathVariable int studentId) {
        if ((studentId >= theStudents.size()) || (studentId < 0)) {
            throw new StudentNotFoundException("Student id " + studentId + " not found");
        }
        return theStudents.get(studentId);
    }
}
